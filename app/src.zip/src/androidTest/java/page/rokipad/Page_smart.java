package page.rokipad;

import android.support.test.uiautomator.By;
import android.support.test.uiautomator.UiDevice;
import android.support.test.uiautomator.UiObject;
import android.support.test.uiautomator.UiObject2;
import android.support.test.uiautomator.UiObjectNotFoundException;
import android.support.test.uiautomator.UiScrollable;
import android.support.test.uiautomator.UiSelector;
import android.support.test.uiautomator.Until;
import android.util.Log;

import base.BasePage;
import framework.ParameterException;
import lib.ComUtil;
import lib.LogUtil;
import lib.MethodDescription;
import lib.VariableDescription;
import testcase.pad.uitest.RokiPad_smart;

import static config.Config.TAG_PACKAGEPAD;
import static config.Config.delayTimeMs;
import static lib.ComUtil.ClickElement;
import static lib.ComUtil.WaitForExists;
import static lib.ComUtil.mDevice;
import static lib.ComUtil.time;

/**
 * Created by liuxh on 2018/8/31.
 */

public class Page_smart extends BasePage {

    private final String MIN_1 = "1";

    private UiScrollable uiScrollable ;

    @VariableDescription("恢复出厂设置")
    private UiObject2 dataReset;

    @VariableDescription("爆炒时间")
    private UiObject2 variableTime;

    @VariableDescription("换气天数")
    private UiObject2 aerationDay;

    @VariableDescription("星期")
    private UiObject2 weekDay;

    @VariableDescription("北京时间")
    private UiObject2 timeDay;

    @VariableDescription("固定换气开关")
    private UiObject2 breath_time_switch;

    @VariableDescription("自动换气开关")
    private UiObject2 aeration_switch;

    @VariableDescription("3D手势开关")
    private UiObject2 gesture_switch;

    @VariableDescription("爆炒时间开关")
    private UiObject2 variable_time_switch;

    public Page_smart() { }


    //获取爆炒时间
    public String getVariablTime(){
        return WaitForExists(By.res(TAG_PACKAGEPAD, "tv_variable_time")).getText();
    }

    //获取星期
    public String getWeekDay(){
        return WaitForExists(By.res(TAG_PACKAGEPAD, "tv_week_day")).getText();
    }

    //获取北京时间
    public String getTimeDay(){
        return WaitForExists(By.res(TAG_PACKAGEPAD, "tv_time_day")).getText();
    }

    //获取通风天数
    public String getAerationDay(){
        return WaitForExists(By.res(TAG_PACKAGEPAD, "tv_aeration_day")).getText();
    }




    /**
     * 点击设置变频爆炒时间
     * @throws Exception
     */
    public void clickVariablTime() throws Exception {
        if (dataReset == null){
            //uiScrollable = new UiScrollable(new UiSelector().className("android.widget.ScrollView"));
            /*dataReset = uiScrollable.getChildByText(new
                    UiSelector().className("android.widget.TextView"),"3", true);*/
            dataReset =  WaitForExists(By.res(TAG_PACKAGEPAD, "tv_variable_time"));
        }
        dataReset.click();
        LogUtil.d(TAG,"点击"+Page_smart.class.getDeclaredField("dataReset")
                .getAnnotation(VariableDescription.class).value());
        time(delayTimeMs);
    }

    /**
     * 点击设星期几
     * @throws Exception
     */
    public void clickWeekDay() throws Exception {
        if (weekDay == null){
            if (!mDevice.wait(Until.hasObject(By.res(TAG_PACKAGEPAD, "tv_week_day")),1000)){
                mDevice.drag(300,400, 300,200,10);
            }
            weekDay =  WaitForExists(By.res(TAG_PACKAGEPAD, "tv_week_day"));
        }
        weekDay.click();
        LogUtil.d(TAG,"点击"+Page_smart.class.getDeclaredField("weekDay")
                .getAnnotation(VariableDescription.class).value());
        time(delayTimeMs);
    }

    /**
     * 点击设通风时间
     * @throws Exception
     */
    public void clickTimeDay() throws Exception {
        if (timeDay == null){
            if (!mDevice.wait(Until.hasObject(By.res(TAG_PACKAGEPAD, "tv_time_day")),1000)){
                mDevice.drag(300,400, 300,200,10);
            }
            timeDay =  WaitForExists(By.res(TAG_PACKAGEPAD, "tv_time_day"));
        }
        timeDay.click();
        LogUtil.d(TAG,"点击"+Page_smart.class.getDeclaredField("timeDay")
                .getAnnotation(VariableDescription.class).value());
        time(delayTimeMs);
    }



    /**
     * 点击设换气天数
     * @throws Exception
     */
    public void clickAerationDay() throws Exception {
        if (aerationDay == null){
            aerationDay =  WaitForExists(By.res(TAG_PACKAGEPAD, "tv_aeration_day"));
        }
        aerationDay.click();
        LogUtil.d(TAG,"点击"+Page_smart.class.getDeclaredField("aerationDay")
                .getAnnotation(VariableDescription.class).value());
        time(delayTimeMs);
    }


    /**
     * 点击自动换气开关
     * @throws Exception
     */
    public void clickAerationSwitch() throws Exception {
        if (aeration_switch == null){
            aeration_switch =  WaitForExists(By.res(TAG_PACKAGEPAD, "iv_fan_aeration_switch"));
        }
        aeration_switch.click();
        LogUtil.d(TAG,"点击"+Page_smart.class.getDeclaredField("aeration_switch")
                .getAnnotation(VariableDescription.class).value());
        time(delayTimeMs);
    }

    /**
     * 点击固定通风开关
     * @throws Exception
     */
    public void clickBreathTimeSwitch() throws Exception {
        if (breath_time_switch == null){
            if (!mDevice.wait(Until.hasObject(By.res(TAG_PACKAGEPAD, "iv_fan_breath_time_switch")),3000)){
                mDevice.drag(300,400, 300,200,10);
            }
            breath_time_switch =  WaitForExists(By.res(TAG_PACKAGEPAD, "iv_fan_breath_time_switch"));
        }
        breath_time_switch.click();
        LogUtil.d(TAG,"点击"+Page_smart.class.getDeclaredField("breath_time_switch")
                .getAnnotation(VariableDescription.class).value());
        time(delayTimeMs);
    }

    /**
     * 点击爆炒时间开关
     * @throws Exception
     */
    public void clickVariableSwitch() throws Exception {
        if (variable_time_switch == null){
            variable_time_switch =  WaitForExists(By.res(TAG_PACKAGEPAD, "iv_variable_time_switch"));
        }
        variable_time_switch.click();
        LogUtil.d(TAG,"点击"+Page_smart.class.getDeclaredField("variable_time_switch")
                .getAnnotation(VariableDescription.class).value());
        time(delayTimeMs);
    }

    /**
     * 点击3D手势开关
     * @throws Exception
     */
    public void clickGestureSwitch() throws Exception {
        //正常控件获取不知为何不起作用，这里采用坐标点击
        mDevice.drag(300,200, 300,400,10);
        time(delayTimeMs);
        ClickElement(507,189,562,219);
        LogUtil.d(TAG,"点击"+Page_smart.class.getDeclaredField("gesture_switch")
                .getAnnotation(VariableDescription.class).value());
        time(delayTimeMs);
    }



    public void SetWeekDay(String day) throws InterruptedException {
        int offset = 0;
        switch (day){
            case "周一":  offset=0;break;
            case "周二":  offset=1;break;
            case "周三":  offset=2;break;
            case "周四":  offset=3;break;
            case "周五":  offset=4;break;
            case "周六":  offset=5;break;
            case "周日":  offset=6;break;
        }

        for(int i = 0; i<offset; i++){
            mDevice.click(632,420);
            time(delayTimeMs);
        }

        WaitForExists(By.res(TAG_PACKAGEPAD, "tv_affirm")).click();
        time(delayTimeMs);
    }

    public void SetTimeDay(int hour, int min) throws InterruptedException {
        int offsetHour = Math.abs( hour-12);
        int offsetMin = Math.abs( min-30);

        if (hour >= 12){
            for(int i = 0; i<offsetHour; i++){
                mDevice.click(550,410);
                time(delayTimeMs);
            }
        }else {
            for(int i = 0; i<offsetHour; i++){
                mDevice.click(550,300);
                time(delayTimeMs);
            }
        }

        if (min >= 30){
            for(int i = 0; i<offsetMin; i++){
                mDevice.click(700,410);
                time(delayTimeMs);
            }
        }else {
            for(int i = 0; i<offsetMin; i++){
                mDevice.click(700,300);
                LogUtil.d(TAG,"I:"+i);
                time(delayTimeMs);
            }
        }

        WaitForExists(By.res(TAG_PACKAGEPAD, "tv_affirm")).click();
        time(delayTimeMs);
    }



    public void SetAerationDay(int day) throws InterruptedException {
        int offset = Math.abs( day-3);
        if (day >= 3){
            for(int i = 0; i<offset; i++){
                mDevice.click(632,420);
                time(delayTimeMs);
            }
        }else {
            for(int i = 0; i<offset; i++){
                mDevice.click(632,300);
                time(delayTimeMs);
            }
        }
        WaitForExists(By.res(TAG_PACKAGEPAD, "tv_affirm")).click();
        time(delayTimeMs);
    }


    /**
     * 操作换气和爆炒空间选择参数，这两个控件类似，用同一个函数操作
     * @param var
     * @throws InterruptedException
     */
    public void SetVar(int var) throws InterruptedException {
        int offset = Math.abs( var-3);
        if (var >= 3){
            for(int i = 0; i<offset; i++){
                mDevice.click(632,420);
                time(delayTimeMs);
            }
        }else {
            for(int i = 0; i<offset; i++){
                mDevice.click(632,300);
                time(delayTimeMs);
            }
        }
        WaitForExists(By.res(TAG_PACKAGEPAD, "tv_affirm")).click();
        time(delayTimeMs);
    }

}

