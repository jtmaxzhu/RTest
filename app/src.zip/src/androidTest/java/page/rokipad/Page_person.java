package page.rokipad;

import android.support.test.uiautomator.By;
import android.support.test.uiautomator.UiDevice;
import android.support.test.uiautomator.UiObject2;
import android.support.test.uiautomator.UiObjectNotFoundException;

import base.BasePage;
import framework.ParameterException;
import lib.VariableDescription;

import static config.Config.TAG_PACKAGEPAD;
import static config.Config.delayTimeMs;
import static lib.ComUtil.WaitForExists;
import static lib.ComUtil.time;

/**
 * Created by liuxh on 2018/8/31.
 */

public class Page_person extends BasePage {
    UiDevice uiDevice;
    /**
     *  定义控件变量名称以及对应的文字标签
     *  tvlogin        ：  登录
     *  addDevice      ：  添加新设备
     */
    @VariableDescription("主页面登录")
    private UiObject2 tvlogin;

    @VariableDescription("添加新设备")
    private UiObject2 addDevice;

    public Page_person() { }

    /**
     * 点击手机登录按钮
     * @throws Exception
     */
    public void clickTvLogin() throws Exception{
        if (tvlogin == null){
            tvlogin = WaitForExists(By.res(TAG_PACKAGEPAD, "tv_login"));
        }
        tvlogin.click();
        time(delayTimeMs);
    }


    /**
     * 点击添加设备
     * @throws Exception
     */
    public void clickAddDevice() throws Exception{
        if (addDevice == null){
            addDevice = WaitForExists(By.res(TAG_PACKAGEPAD, "iv_add_device"));
        }
        addDevice.click();
        time(delayTimeMs);
    }
}

