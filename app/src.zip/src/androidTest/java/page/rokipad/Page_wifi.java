package page.rokipad;

import android.support.test.uiautomator.By;
import android.support.test.uiautomator.UiDevice;
import android.support.test.uiautomator.UiObject2;
import android.support.test.uiautomator.UiObjectNotFoundException;

import java.util.concurrent.TimeUnit;

import base.BasePage;
import framework.ParameterException;
import lib.VariableDescription;

import static config.Config.TAG_PACKAGEPAD;
import static config.Config.delayTimeMs;
import static lib.ComUtil.WaitForExists;
import static lib.ComUtil.time;

/**
 * Created by liuxh on 2018/8/31.
 */

public class Page_wifi extends BasePage {
    UiDevice uiDevice;
    /**
     *  定义控件变量名称以及对应的文字标签
     *  wifiContr      ：  "WiFi开关按钮"
     *  skip           ：  "跳过"
     */
    @VariableDescription("WiFi开关")
    private UiObject2 wifiContr;

    @VariableDescription("跳过")
    private UiObject2 skip;


    public Page_wifi() {
    }

    /**
     * 点击wifi按钮
     * @throws Exception
     */
    public void clickWifi() throws Exception{
        if (wifiContr == null){
            wifiContr = WaitForExists(By.res(TAG_PACKAGEPAD, "wifi_control"));
        }
        wifiContr.click();
        time(delayTimeMs);
    }

    /**
     * 点击跳过按钮
     * @throws Exception
     */
    public void clickSkip() throws Exception{
        if (skip == null){
            skip = WaitForExists(By.res(TAG_PACKAGEPAD, "guid_wifi_skip"));
        }
        skip.click();
        time(delayTimeMs);
    }


}

