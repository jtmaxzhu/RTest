package page.rokipad;

import android.support.test.uiautomator.By;
import android.support.test.uiautomator.UiDevice;
import android.support.test.uiautomator.UiObject2;
import android.support.test.uiautomator.UiObjectNotFoundException;

import base.BasePage;
import framework.ParameterException;
import lib.VariableDescription;

import static config.Config.TAG_PACKAGEPAD;
import static config.Config.delayTimeMs;
import static lib.ComUtil.WaitForExists;
import static lib.ComUtil.time;

/**
 * Created by liuxh on 2018/8/31.
 */

public class Page_logout extends BasePage {

    @VariableDescription("确认选项")
    private UiObject2 tvOk;

    @VariableDescription("取消选项")
    private UiObject2 tvCancel;

    public Page_logout(){ }

    /**
     * 点击确定
     * @throws Exception
     */
    public void clickOK() throws Exception{
        if (tvOk == null){
            tvOk = WaitForExists(By.res(TAG_PACKAGEPAD, "tv_ok"));
        }
        tvOk.click();
        time(delayTimeMs);
    }

    /**
     * 点击取消
     * @throws Exception
     */
    public void clickCancel() throws Exception{
        if (tvCancel == null){
            tvCancel = WaitForExists(By.res(TAG_PACKAGEPAD, "tv_cancel"));
        }
        tvCancel.click();
        time(delayTimeMs);
    }

}

