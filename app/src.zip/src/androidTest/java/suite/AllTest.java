package suite;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import testcase.roki.perftest.ROKI_Login;
import testcase.roki.uitest.ROKI_About;
import testcase.roki.uitest.ROKI_AfterSale;
import testcase.roki.uitest.ROKI_FoodShop;
import testcase.roki.uitest.ROKI_MyCollection;


/**
 * Created by Administrator on 2018/8/11 0011.
 */

@RunWith(Suite.class)
@Suite.SuiteClasses({
        ROKI_Login.class,
/*        ROKI_MyCollection.class,
        ROKI_FoodShop.class,
        ROKI_About.class,
        ROKI_AfterSale.class*/
})
public class AllTest {
}
