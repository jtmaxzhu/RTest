package base;

import android.app.Instrumentation;
import android.content.Context;
import android.support.test.InstrumentationRegistry;

import lib.ComUtil;


/**
 * Created by Administrator on 2018/8/31.
 */

public class BasePage{

    public static Instrumentation mInstrumentation = null;
    public static Context mContext = null;
    public static ComUtil comUtil = ComUtil.getInstance();
    public static String TAG = "LogRTest";

    public BasePage(){
        mContext = InstrumentationRegistry.getContext();
        mInstrumentation = InstrumentationRegistry.getInstrumentation();
    }

}
