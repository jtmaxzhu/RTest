package config;

/**
 * Created by Administrator on 2018/7/24 0024.
 */

public class Config {
    public static final String TAG_PACKAGE = "com.robam.roki";
    public static final String TAG_ACTIVITY = "com.robam.roki/.ui.form.WelcomeActivity";
    public static final String TAG_PACKAGEPAD = "com.robam.rokipad";
    public static final String TAG_ACTIVITYPAD = "com.robam.rokipad/.ui.from.GuideActivity";
    //操作之间的延时时间
    public static int delayTimeMs = 300;
}
