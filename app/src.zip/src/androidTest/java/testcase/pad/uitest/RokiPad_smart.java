package testcase.pad.uitest;

import android.support.test.uiautomator.By;
import android.support.test.uiautomator.SearchCondition;
import android.support.test.uiautomator.UiObject2;
import android.support.test.uiautomator.UiObjectNotFoundException;
import android.support.test.uiautomator.Until;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import base.rokipad.BaseTest;
import lib.LogUtil;
import lib.MethodDescription;
import page.rokipad.Page_leftbar;
import page.rokipad.Page_rightbar;
import page.rokipad.Page_smart;

import static config.Config.TAG_PACKAGEPAD;
import static config.Config.delayTimeMs;
import static lib.ComUtil.WaitForExists;
import static lib.ComUtil.mDevice;
import static lib.ComUtil.time;


/**
 * Created by Administrator on 2018/9/2 0002.
 * wifi相关的测试用例
 */

public class RokiPad_smart extends BaseTest {

    private static final String hint = "您没开启此功能不可设置";

    @Before
    @MethodDescription("环境初始化")
    public void init() throws Exception {
        if (!mDevice.wait(Until.hasObject(By.res(TAG_PACKAGEPAD,"tv_fan_factory_data_reset")),1000)){
            //点击侧边栏登录按钮
            Page_leftbar leftbar = new Page_leftbar();
            leftbar.clickLogin();

            //点击右侧边栏智能设定
            Page_rightbar rightbar = new Page_rightbar();
            rightbar.clickSmartSet();
        }
    }

    @Test
    @MethodDescription("设置爆炒时间")
    public void SetVariablTime() throws Exception {
        LogUtil.d(TAG,"启动---测试用例---"+RokiPad_smart.class.getDeclaredMethod("SetVariablTime")
                .getAnnotation(MethodDescription.class).value());
        Page_smart smart = new Page_smart();
        smart.clickVariablTime();
        //判断开关是否打开，如果没打开就打开
        if (processToast(hint)){
            smart.clickVariableSwitch();
            smart.clickVariablTime();
        }
        smart.SetVar(1);
        Assert.assertEquals("1", smart.getVariablTime());
        smart.clickVariablTime();
        smart.SetVar(9);
        Assert.assertEquals("9", smart.getVariablTime());
        smart.clickVariablTime();
        smart.SetVar(3);
        Assert.assertEquals("3", smart.getVariablTime());
        LogUtil.d(TAG,"结束---测试用例---"+RokiPad_smart.class.getDeclaredMethod("SetVariablTime")
                .getAnnotation(MethodDescription.class).value());
    }

    @Test
    @MethodDescription("设置每周固定通风时间")
    public void SetBreathDay() throws Exception {
        LogUtil.d(TAG,"启动---测试用例---"+RokiPad_smart.class.getDeclaredMethod("SetBreathDay")
                .getAnnotation(MethodDescription.class).value());
        Page_smart smart = new Page_smart();
        smart.clickWeekDay();
        //判断开关是否打开，如果没打开就打开
        if (processToast(hint)){
            smart.clickBreathTimeSwitch();
            smart.clickWeekDay();
        }
        smart.SetWeekDay("周六");
        smart.clickTimeDay();
        smart.SetTimeDay(16,52);
        Assert.assertEquals("周六", smart.getWeekDay());
        Assert.assertEquals("16:52", smart.getTimeDay());

        smart.clickWeekDay();
        smart.SetWeekDay("周三");
        smart.clickTimeDay();
        smart.SetTimeDay(12,30);
        LogUtil.d(TAG,"结束---测试用例---"+RokiPad_smart.class.getDeclaredMethod("SetBreathDay")
                .getAnnotation(MethodDescription.class).value());
    }

    @Test
    @MethodDescription("设置换气天数")
    public void SetAerationDay() throws Exception {
        LogUtil.d(TAG,"启动---测试用例---"+RokiPad_smart.class.getDeclaredMethod("SetAerationDay")
                .getAnnotation(MethodDescription.class).value());
        Page_smart smart = new Page_smart();
        smart.clickAerationDay();
        //判断开关是否打开，如果没打开就打开
        if (processToast(hint)){
            smart.clickAerationSwitch();
            smart.clickAerationDay();
        }
        smart.SetVar(9);
        Assert.assertEquals("9", smart.getAerationDay());
        smart.clickAerationDay();
        smart.SetVar(1);
        Assert.assertEquals("1", smart.getAerationDay());
        smart.clickAerationDay();
        smart.SetVar(3);
        Assert.assertEquals("3", smart.getAerationDay());
        LogUtil.d(TAG,"结束---测试用例---"+RokiPad_smart.class.getDeclaredMethod("SetAerationDay")
                .getAnnotation(MethodDescription.class).value());
    }


    @Test
    @MethodDescription("设置3D手势")
    public void Set3D() throws Exception {
        LogUtil.d(TAG,"启动---测试用例---"+RokiPad_smart.class.getDeclaredMethod("Set3D")
                .getAnnotation(MethodDescription.class).value());
        Page_leftbar leftbar = new Page_leftbar();
        leftbar.clickHome();
        if (mDevice.wait(Until.hasObject(By.res(TAG_PACKAGEPAD, "tv_smart_set")),1000)){
            LogUtil.d(TAG,"3D手势未开启");
            WaitForExists(By.res(TAG_PACKAGEPAD, "tv_smart_set")).click();
            Page_smart smart = new Page_smart();
            smart.clickGestureSwitch();
            leftbar.clickHome();
            time(delayTimeMs);
            Assert.assertTrue(!mDevice.wait(Until.hasObject(By.res(TAG_PACKAGEPAD, "tv_smart_set")),1000));
        }else {
            LogUtil.d(TAG,"3D手势已开启");
            leftbar.clickSet();
            Page_rightbar rightbar = new Page_rightbar();
            rightbar.clickSmartSet();
            Page_smart smart = new Page_smart();
            smart.clickGestureSwitch();
            leftbar.clickHome();
        }

        LogUtil.d(TAG,"结束---测试用例---"+RokiPad_smart.class.getDeclaredMethod("Set3D")
                .getAnnotation(MethodDescription.class).value());
    }


    @Test
    @MethodDescription("恢复出厂设置")
    public void SetDataReset() throws Exception {
        LogUtil.d(TAG,"启动---测试用例---"+RokiPad_smart.class.getDeclaredMethod("SetDataReset")
                .getAnnotation(MethodDescription.class).value());
        Page_smart smart = new Page_smart();

        LogUtil.d(TAG,"结束---测试用例---"+RokiPad_smart.class.getDeclaredMethod("SetDataReset")
                .getAnnotation(MethodDescription.class).value());
    }







}
