package testcase.pad.uitest;

import android.support.test.uiautomator.By;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.concurrent.TimeUnit;

import base.rokipad.BaseTest;
import lib.LogUtil;
import lib.MethodDescription;
import page.rokipad.Page_person;
import page.rokipad.Page_logout;
import page.rokipad.Page_leftbar;
import page.rokipad.Page_login;
import page.rokipad.Page_wifi;

import static config.Config.TAG_ACTIVITYPAD;
import static config.Config.TAG_PACKAGEPAD;
import static lib.ComUtil.WaitForExists;


/**
 * Created by Administrator on 2018/9/2 0002.
 * 登录相关的测用例
 */

public class RokiPad_login extends BaseTest {
    private static Page_login login;
    private static Page_person info;
    private static final String hintUser = "请输入有效的手机号";
    private static final String hintPwd = "密码不能为空";
    private static final String hintLogin = "用户登录成功";
    private static final String hinterr = "账号或密码错误";





    @BeforeClass
    public static void initTest()  {

    }

    @Before
    @MethodDescription("测试环境初始化")
    public void init() throws Exception {
        LogUtil.d(TAG,"----------------"+RokiPad_login.class.getDeclaredMethod("init")
                .getAnnotation(MethodDescription.class).value()+"----------------");

        //点击侧边栏登录按钮
        Page_leftbar leftbar = new Page_leftbar();
        leftbar.clickLogin();

        //点击中间登录按钮
        info = new Page_person();
        info.clickTvLogin();
    }

    /**
     * 正常登录流程，用户名密码均正确
     * @throws
     */
    @Test
    @MethodDescription("正常登录")
    public void loginNormal() throws Exception {
        LogUtil.d(TAG,"启动---测试用例---"+RokiPad_login.class.getDeclaredMethod("loginNormal")
                .getAnnotation(MethodDescription.class).value());
        login = new Page_login();
        login.setAccount("13655197396");
        login.setPwd("123456");
        login.clickLogin();
        Assert.assertTrue("未发现"+ hintLogin +"提示信息!",  processToast(hintLogin));
        //退出登录
        info.clickTvLogin();
        Page_logout isOK = new Page_logout();
        isOK.clickOK();
        LogUtil.d(TAG,"结束---测试用例---"+RokiPad_login.class.getDeclaredMethod("loginNormal")
                .getAnnotation(MethodDescription.class).value());
    }

    /**
     * 用户名为空
     * @throws Exception
     */
    @Test
    @MethodDescription("用户名为空")
    public void loginUserNotFill() throws Exception {
        LogUtil.d(TAG,"启动---测试用例---"+RokiPad_login.class.getDeclaredMethod("loginUserNotFill")
                .getAnnotation(MethodDescription.class).value());
        login = new Page_login();
        login.setPwd("123456");
        login.clickLogin();
        final String warning = WaitForExists(By.res(TAG_PACKAGEPAD, "warning")).getText();
        Assert.assertEquals(hintUser, warning);
        login.clickBack();
        LogUtil.d(TAG,"结束---测试用例---"+RokiPad_login.class.getDeclaredMethod("loginUserNotFill")
                .getAnnotation(MethodDescription.class).value());

    }

    /**
     * 密码为空
     * @throws Exception
     */
    @Test
    @MethodDescription("密码为空")
    public void loginPassNotFill() throws Exception {
        LogUtil.d(TAG,"启动---测试用例---"+RokiPad_login.class.getDeclaredMethod("loginPassNotFill")
                .getAnnotation(MethodDescription.class).value());
        login = new Page_login();
        login.setAccount("13655197396");
        login.clickLogin();
        Assert.assertTrue("未发现“用户登录成功”提示信息!",  processToast(hintPwd));
        login.clickBack();
        LogUtil.d(TAG,"结束---测试用例---"+RokiPad_login.class.getDeclaredMethod("loginPassNotFill")
                .getAnnotation(MethodDescription.class).value());
    }

    /**
     * 错误密码
     * @throws Exception
     */
    @Test
    @MethodDescription("错误密码")
    public void  loginPassMistake() throws Exception {
        LogUtil.d(TAG,"启动---测试用例---"+RokiPad_login.class.getDeclaredMethod("loginPassMistake")
                .getAnnotation(MethodDescription.class).value());
        login = new Page_login();
        login.setAccount("13655197396");
        login.setPwd("1234567");
        login.clickLogin();
        Assert.assertTrue("未发现"+ hinterr +"提示信息!",  processToast(hinterr));
        //退出登录
        login.clickBack();
        LogUtil.d(TAG,"结束---测试用例---"+RokiPad_login.class.getDeclaredMethod("loginPassMistake")
                .getAnnotation(MethodDescription.class).value());
    }


    @After
    public void close() throws Exception {

    }






}
