package testcase.pad.uitest;

import android.support.test.uiautomator.By;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.concurrent.TimeUnit;

import base.rokipad.BaseTest;
import page.rokipad.Page_person;
import page.rokipad.Page_logout;
import page.rokipad.Page_leftbar;
import page.rokipad.Page_login;
import page.rokipad.Page_wifi;

import static config.Config.TAG_ACTIVITYPAD;
import static config.Config.TAG_PACKAGEPAD;
import static lib.ComUtil.WaitForExists;


/**
 * Created by Administrator on 2018/9/2 0002.
 * wifi相关的测试用例
 */

public class RokiPad_wifi extends BaseTest {




}
