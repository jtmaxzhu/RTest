package lib.pictool;

/**
 * Created by Administrator on 2018/7/24 0024.
 * 该类用于定义设备交互界面控件不同状态截图存放路径
 */

public class PicPath {

    //临时图片存储路径
    public static String temp = "/sdcard/temp/temp.png";
    //烟机操作控件截图源文件
    public static String fry_close = "/sdcard/temp/source/fry_close.png";
    public static String fry_open = "/sdcard/temp/source/fry_open.png";
    public static String decoct_open = "/sdcard/temp/source/decoct_open.png";
    public static String decoct_close = "/sdcard/temp/source/decoct_close.png";
    public static String stew_open = "/sdcard/temp/source/stew_open.png";
    public static String stew_close = "/sdcard/temp/source/stew_close.png";


    public static String test1 = "/sdcard/temp/source/test1.png";
    public static String test2 = "/sdcard/temp/source/test2.png";
    public static String test3 = "/sdcard/temp/source/test3.png";
    public static String test4 = "/sdcard/temp/source/test4.png";

    public static String test5 = "/sdcard/temp/source/test5.png";
    public static String test6 = "/sdcard/temp/source/test6.png";
    public static String test7 = "/sdcard/temp/source/test7.png";
    public static String test8 = "/sdcard/temp/source/test8.png";


    //测试文件
    public static String StewStatus = "/sdcard/temp/target/StewStatus.png";



}

