package framework.core;

import android.support.test.uiautomator.UiDevice;

import org.junit.rules.TestRule;
import org.junit.runner.Description;
import org.junit.runners.model.Statement;

import lib.ComUtil;


/**
 * Created by Administrator on 2018/7/30.
 * 该类用于配置junit用例失败重新运行
 */

public class RetryRule implements TestRule{
    private final int retryCount;
    //构造方法
    public RetryRule(int retryCount){
        this.retryCount=retryCount;
    }

    public UiDevice mDevice = ComUtil.getInstance().getDevice();

    @Override
    public Statement apply(Statement base, Description description) {
        return statement(base,description);
    }

    private Statement statement(final Statement base, final Description description){
        return new Statement() {
            @Override
            public void evaluate() throws Throwable {
                String className = description.getClassName();
                String methodName = description.getMethodName();
                Throwable caughtThrowable=null;
                for(int i=0;i<retryCount;i++){
                    try {
                        base.evaluate();
                        return;
                    }catch (final Throwable t){
                        caughtThrowable = t;
                        //mDevice.takeScreenshot(new File("/sdcard/temp/err1/"+className+"_"+methodName+".jpg"));
                        System.err.println(description.getDisplayName()+":run"+(i+1)+"failed.");
                    }
                }
                System.err.println(description.getDisplayName()+":giving up after"+retryCount+"failure.");
                assert caughtThrowable != null;
                throw caughtThrowable;
            }

        };

 }
}
